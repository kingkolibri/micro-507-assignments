function u = control(q, dq)
u = zeros(2, 1);
end